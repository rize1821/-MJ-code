﻿# 핵심파일 목록

이 문서는 증빙자료 폴더에 포함한 핵심 파일과 제외/미존재 항목을 정리합니다.

| 구분 | 원본 경로 | 증빙자료 경로 | 역할 | 제출서류 활용 항목 |
|---|---|---|---|---|
| UI | $source | $dest | 정적 앱 진입 HTML 및 public config/main script 로딩 순서 증빙 | 개발제품 개요, 실현가능성 |
| UI | $source | $dest | 앱 초기화 진입점 | 개발제품 개요 |
| UI | $source | $dest | 입력 화면, 결과 패널, 지도 fallback UI 스타일 | 기능 및 특징 |
| UI | $source | $dest | 입력 폼, 결과 카드, 추천 흐름, infraOnly 모드, API 호출 연결 | 개발제품 개요, 기능 및 특징, 기술성 |
| 지도 | $source | $dest | 네이버 지도, 행정동 경계, 마커, 연결선, 지도 bounds 제어 | 기능 및 특징, 시각화 |
| 지도 | $source | $dest | 네이버 지도 스크립트 로딩 | 기능 및 특징 |
| 지도 | $source | $dest | 천안·아산 지도 범위 제한과 viewport 복원 | 기술성, 지도 시각화 |
| 지도 | $source | $dest | GeoJSON polygon 좌표 변환 | 공공데이터 활용, 지도 시각화 |
| 지도 | $source | $dest | 좌표 기반 행정동 polygon 매칭 | 공공데이터 활용, 기술성 |
| 지도 | $source | $dest | 거리 계산 유틸 | 추천 알고리즘, 기술성 |
| 추천 알고리즘 | $source | $dest | 인프라 3축 점수, 사용자 중요도, 상대등급, TOP/비추천 선정 | 주요 기술성, 기능 및 특징 |
| 추천 알고리즘 | $source | $dest | 생활권 통근 점수 결합 보조 로직 | 기술성 |
| 추천 알고리즘 | $source | $dest | 통근 적합도, 최종 재랭킹, 초과 패널티, 도보 60분 제한, API 실패 정책 | 주요 기술성, 차별성 |
| 추천 알고리즘 | $source | $dest | 48개 후보 1차 평가 및 API 호출 대상 제한 | 기술성, 차별성 |
| 추천 알고리즘 | $source | $dest | 통근 현실성 상태와 추천 가능 후보 판정 | 기능 및 특징, 기술성 |
| 추천 알고리즘 | $source | $dest | 거리 기반 보조 추정 및 실제 API 결과 병합 | 기술성 |
| 추천 알고리즘 | $source | $dest | 요청 후보 파일은 없음. 대체 파일 `src/utils/commuteEstimator.js` 확인됨 | 경로 확인 필요 |
| 추천 알고리즘 | $source | $dest | 선택 통근수단별 API 호출 정책 분리 | API 최적화, 기술성 |
| 추천 알고리즘 | $source | $dest | 읍·면 리 단위 보조 문구 생성 | 공공데이터 활용, 기능 및 특징 |
| 추천 알고리즘 | $source | $dest | 충남 주소에서 시/구/읍면동/리 추출 | 공공데이터 전처리, 기술성 |
| 추천 알고리즘 | $source | $dest | 결과 카드의 네이버 길찾기 링크 생성 | 기능 및 특징 |
| API 연동 | $source | $dest | 자동차 batch API 프론트 호출 및 결과 정규화 | 기능 및 특징, 기술성 |
| API 연동 | $source | $dest | ODsay 대중교통 경로 호출, 캐시, 실패 정규화 | 기능 및 특징, 기술성 |
| API 연동 | $source | $dest | TMAP 도보 batch API 프론트 호출 및 결과 정규화 | 기능 및 특징, 기술성 |
| API 연동 | $source | $dest | Naver Directions 5 서버리스 핵심 호출 로직 | 기술성, 보안형 API 연동 |
| API 연동 | $source | $dest | 단건 자동차 통근 서버리스 API | 기술성 |
| API 연동 | $source | $dest | 자동차 batch 서버리스 API | 기능 및 특징, 기술성 |
| API 연동 | $source | $dest | TMAP 보행자 경로 batch 서버리스 API | 기능 및 특징, 기술성 |
| 데이터 | $source | $dest | 전처리 CSV 기반 천안·아산 생활권 48개 generated 데이터 | 공공데이터 활용, 제품 개요 |
| 데이터 | $source | $dest | 천안·아산 행정동 경계 48개 FeatureCollection | 공공데이터 활용, 지도 시각화 |
| 데이터 | $source | $dest | mock 모드 직장/생활권 중심 좌표 | 시연, 데이터 모드 |
| 데이터 | $source | $dest | CSV 파일별 인프라 축, 처리 방식, 가중치 설정 | 공공데이터 활용, 기술성 |
| 데이터 | $source | $dest | generated/mock 데이터 모드 선택 | 실현가능성 |
| 데이터 | $source | $dest | 생활권 데이터 저장소 및 generated 우선 사용 흐름 | 제품 개요, 공공데이터 활용 |
| 데이터 | $source | $dest | 시연용 mock 생활권 데이터 | 시연 가능성 |
| 데이터 | $source | $dest | 직장 읍면동 선택 옵션 생성 | 기능 및 특징 |
| 데이터 | $source | $dest | 생활권 데이터 구조 타입 정의 | 기술성, 데이터 구조 |
| 배포/설정 | $source | $dest | 테스트, 빌드, 개발 서버 명령 정의 | 실현가능성 |
| 배포/설정 | $source | $dest | Vercel buildCommand와 outputDirectory 설정 | 배포, 실현가능성 |
| 배포/설정 | $source | $dest | 환경변수 이름 placeholder 문서화 | 보안형 환경변수 관리 |
| 배포/설정 | $source | $dest | 원본에 실제 공개 Client ID로 보이는 값이 있어 민감정보 의심 파일로 제외 | 보안 확인 필요 |
| 배포/설정 | $source | $dest | 정적 앱 구조와 보안 금지 항목 검증 | 품질관리, 실현가능성 |
| 배포/설정 | $source | $dest | Vercel 정적 산출물 생성 스크립트 | 배포, 실현가능성 |
| 데이터 | $source | $dest | 전처리 CSV에서 generatedLifeZones 생성 | 공공데이터 활용, 기술성 |
| 데이터 | $source | $dest | 전처리 CSV 진단 | 공공데이터 활용 |
| 데이터 | $source | $dest | 행정동 경계 GeoJSON 변환 | 공공데이터 활용, 지도 |
| 데이터 | $source | $dest | VWorld 경계 GeoJSON 변환 후보 스크립트 | 지도, 확장성 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 통근 현실성 필터 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | API 호출량 제한 및 shortlist 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 통근 점수, 초과 패널티, 도보 제한 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | Naver Directions 자동차 API 안전 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | Naver Directions 자동차 API 안전 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 생활권 데이터/점수/후보 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 직장 선택안함 인프라-only 모드 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 생활권 데이터/점수/후보 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 생활권 데이터/점수/후보 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 생활권 데이터/점수/후보 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | ODsay 대중교통 API 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 지도 경계와 좌표 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | TMAP 도보 API 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | TMAP 도보 API 처리 검증 | 테스트 및 품질관리 |
| 테스트 | $source | $dest | 기능 회귀 테스트 | 테스트 및 품질관리 |
| 문서 | $source | $dest | 생활권 점수 산정 및 데이터 처리 계획 | 공공데이터 활용, 기술성 |
| 문서 | $source | $dest | generated 생활권 데이터 생성 결과 요약 | 공공데이터 활용 |
| 문서 | $source | $dest | 전처리 CSV 진단 및 리 단위 가능성 검토 | 공공데이터 활용 |
| 문서 | $source | $dest | 로컬 실행, 공유, 지도 API 동작 방식 설명 | 실현가능성 |
| 문서 | $source | $dest | Vercel 환경변수와 Directions/ODsay 설정 설명 | 배포, 보안형 API 연동 |
| 문서 | $source | $dest | 루트 README.md는 확인되지 않음 | 확인 필요 |
| 제외 | $source | $dest | 원본/전처리 데이터 폴더로 제출 증빙 복사 제외 | 보안/정책 준수 |
| 제외 | $source | $dest | 산출물 폴더로 복사 제외 | 보안/정책 준수 |
| 제외 | $source | $dest | 배포 산출물이며 실제 public key 주입 가능성이 있어 제외 | 보안/정책 준수 |
| 제외 | $source | $dest | 로컬 Secret 파일로 복사 제외 | 보안/정책 준수 |
