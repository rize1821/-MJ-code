const CANVAS_WIDTH = 1280;
const CANVAS_HEIGHT = 720;
const STORAGE_KEY = "3x3-grid-puzzle-rankings-v1";

const canvas = document.querySelector("#gameCanvas");
const ctx = canvas.getContext("2d");
const video = document.querySelector("#webcam");
const topbar = document.querySelector(".topbar");
const statusStrip = document.querySelector(".status-strip");
const startPanel = document.querySelector("#startPanel");
const startForm = document.querySelector("#startForm");
const startButton = document.querySelector("#startButton");
const userIdInput = document.querySelector("#userIdInput");
const cameraPermissionInput = document.querySelector("#cameraPermissionInput");
const instructionPanel = document.querySelector("#instructionPanel");
const finishPanel = document.querySelector("#finishPanel");
const retryButton = document.querySelector("#retryButton");
const restartButton = document.querySelector("#restartButton");
const rankPanel = document.querySelector("#rankPanel");
const rankList = document.querySelector("#rankList");
const resetRankButton = document.querySelector("#resetRankButton");
const playerBadge = document.querySelector("#playerBadge");
const phaseLabel = document.querySelector("#phaseLabel");
const moveText = document.querySelector("#moveText");
const timerText = document.querySelector("#timerText");
const phaseTip = document.querySelector("#phaseTip");
const errorBanner = document.querySelector("#errorBanner");
const finalUser = document.querySelector("#finalUser");
const finalTime = document.querySelector("#finalTime");
const finalMoves = document.querySelector("#finalMoves");

const state = {
  mode: "start",
  userId: "",
  stream: null,
  cameraAuthorized: false,
  hands: null,
  handsReady: false,
  detectionActive: false,
  detectionBusy: false,
  detectionWarningShown: false,
  latestHands: [],
  draftRect: null,
  hadTwoHandPinch: false,
  snapshot: null,
  gridRect: null,
  board: createSolvedBoard(),
  drag: null,
  pointerFrameStart: null,
  timerId: null,
  startTime: null,
  elapsedMs: 0,
  moves: 0,
  rankings: loadRankings()
};

const phaseCopy = {
  start: ["READY", "사용자 ID를 입력하고 카메라 권한을 확인하세요."],
  loading: ["CAMERA", "카메라와 손 인식 모듈을 준비하고 있습니다."],
  instructions: ["PHASE 0: GUIDE", "설명문 위에서 한 손 엄지와 검지를 붙이면 게임 준비가 시작됩니다."],
  framing: ["PHASE 1: CAPTURE", "양손의 엄지와 검지를 붙여 사각형을 만들고, 떼면 3x3 퍼즐로 캡처됩니다."],
  puzzle: ["PHASE 2: SWAP", "한 손 포인트로 타일을 잡아 다른 칸으로 옮기면 두 칸이 교체됩니다."],
  finished: ["FINISH", "기록이 랭킹에 저장되었습니다."]
};

startForm.addEventListener("input", syncStartButton);
cameraPermissionInput.addEventListener("change", handleCameraPermissionCheck);
startForm.addEventListener("submit", handleStart);
retryButton.addEventListener("click", retryGame);
restartButton.addEventListener("click", restartGame);
resetRankButton.addEventListener("click", resetRankings);
instructionPanel.addEventListener("pointerdown", () => {
  if (state.mode === "instructions") {
    beginFraming();
  }
});

canvas.addEventListener("pointerdown", handleCanvasPointerDown);
canvas.addEventListener("pointermove", handleCanvasPointerMove);
canvas.addEventListener("pointerup", handleCanvasPointerUp);
canvas.addEventListener("pointercancel", handleCanvasPointerUp);

canvas.width = CANVAS_WIDTH;
canvas.height = CANVAS_HEIGHT;
syncStartButton();
renderLeaderboard();
updateTopbar();
updatePhaseTip();
requestAnimationFrame(renderScene);

function syncStartButton() {
  const hasId = userIdInput.value.trim().length > 0;
  startButton.disabled = !hasId || !state.cameraAuthorized || !cameraPermissionInput.checked;
}

async function handleCameraPermissionCheck() {
  if (!cameraPermissionInput.checked) {
    state.cameraAuthorized = false;
    stopCamera();
    syncStartButton();
    return;
  }

  hideError();
  state.cameraAuthorized = false;
  cameraPermissionInput.disabled = true;
  startButton.textContent = "카메라 확인 중...";
  syncStartButton();

  try {
    await startCamera();
  } catch (error) {
    cameraPermissionInput.checked = false;
    showCameraError(error);
  } finally {
    cameraPermissionInput.disabled = false;
    startButton.textContent = "Start";
    syncStartButton();
  }
}

async function handleStart(event) {
  event.preventDefault();
  const userId = userIdInput.value.trim();
  if (!userId) {
    return;
  }

  state.userId = userId;
  hideError();

  if (!state.cameraAuthorized) {
    showError("웹캠 또는 연결된 카메라의 권한이 확인되어야 시작할 수 있습니다.");
    syncStartButton();
    return;
  }

  setMode("loading");
  updateTopbar();

  try {
    if (!hasActiveCamera()) {
      await startCamera();
    }
    await initHands();
    startPanel.classList.add("hidden");
    finishPanel.classList.add("hidden");
    instructionPanel.classList.remove("hidden");
    setMode("instructions");
    startDetectionLoop();
  } catch (error) {
    startPanel.classList.remove("hidden");
    showCameraError(error);
    setMode("start");
  }
}

function hasActiveCamera() {
  return Boolean(state.stream?.getVideoTracks().some((track) => track.readyState === "live"));
}

async function startCamera() {
  stopCamera();

  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("MediaDevicesUnavailable");
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    video: {
      width: { ideal: 1280 },
      height: { ideal: 720 },
      facingMode: "user"
    },
    audio: false
  });

  state.stream = stream;
  video.srcObject = stream;
  try {
    await new Promise((resolve) => {
      if (video.readyState >= 1) {
        resolve();
        return;
      }
      video.onloadedmetadata = () => resolve();
    });
    await video.play();
  } catch (error) {
    stream.getTracks().forEach((track) => track.stop());
    state.stream = null;
    video.srcObject = null;
    throw error;
  }

  state.cameraAuthorized = true;
  cameraPermissionInput.checked = true;
}

async function initHands() {
  if (typeof window.Hands === "undefined") {
    state.handsReady = false;
    showError("손 인식 모듈을 불러오지 못했습니다. 인터넷 연결을 확인하거나 마우스로 테스트할 수 있습니다.");
    return;
  }

  if (state.hands) {
    await state.hands.close?.();
  }

  state.hands = new window.Hands({
    locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
  });

  state.hands.setOptions({
    maxNumHands: 2,
    modelComplexity: 1,
    minDetectionConfidence: 0.68,
    minTrackingConfidence: 0.58
  });
  state.hands.onResults(handleHandResults);
  state.handsReady = true;
}

function startDetectionLoop() {
  if (!state.handsReady || !state.hands) {
    return;
  }

  state.detectionActive = true;
  const tick = async () => {
    if (!state.detectionActive) {
      return;
    }

    if (!state.detectionBusy && video.readyState >= 2) {
      state.detectionBusy = true;
      try {
        await state.hands.send({ image: video });
      } catch (error) {
        if (!state.detectionWarningShown) {
          state.detectionWarningShown = true;
          showError("손 인식 모델 실행 중 문제가 발생했습니다. 새로고침 후 다시 시도하거나 마우스로 테스트하세요.");
        }
      } finally {
        state.detectionBusy = false;
      }
    }

    requestAnimationFrame(tick);
  };

  requestAnimationFrame(tick);
}

function handleHandResults(results) {
  state.latestHands = extractHands(results);
  processGestures();
}

function extractHands(results) {
  const landmarks = results.multiHandLandmarks || [];
  const handedness = results.multiHandedness || [];

  return landmarks.map((handLandmarks, index) => {
    const modelLabel = handedness[index]?.label || `Hand ${index + 1}`;
    const label = modelLabel === "Left" ? "LEFT" : modelLabel === "Right" ? "RIGHT" : modelLabel.toUpperCase();
    const thumb = mapLandmark(handLandmarks[4]);
    const indexTip = mapLandmark(handLandmarks[8]);
    const wrist = mapLandmark(handLandmarks[0]);
    const middleKnuckle = mapLandmark(handLandmarks[9]);
    const pinchDistance = distance(thumb, indexTip);
    const handScale = Math.max(distance(wrist, middleKnuckle), 1);
    const threshold = clamp(handScale * 0.54, 24, 58);
    const point = {
      x: (thumb.x + indexTip.x) / 2,
      y: (thumb.y + indexTip.y) / 2
    };

    return {
      id: label,
      label,
      landmarks: handLandmarks.map(mapLandmark),
      thumb,
      indexTip,
      point,
      isPinching: pinchDistance <= threshold,
      pinchDistance,
      threshold
    };
  });
}

function processGestures() {
  const activePinches = state.latestHands.filter((hand) => hand.isPinching);

  if (state.mode === "instructions") {
    const acknowledged = activePinches.some((hand) => pointInsideElement(hand.point, instructionPanel));
    if (acknowledged) {
      beginFraming();
    }
    return;
  }

  if (state.mode === "framing") {
    if (activePinches.length >= 2) {
      state.hadTwoHandPinch = true;
      state.draftRect = rectFromPoints(activePinches[0].point, activePinches[1].point);
      return;
    }

    if (state.hadTwoHandPinch && state.draftRect) {
      captureGrid(state.draftRect);
    }
    return;
  }

  if (state.mode === "puzzle") {
    processPuzzlePinch(activePinches);
  }
}

function beginFraming() {
  resetRoundState();
  instructionPanel.classList.add("hidden");
  finishPanel.classList.add("hidden");
  state.mode = "framing";
  state.draftRect = null;
  state.hadTwoHandPinch = false;
  updateTopbar();
  updatePhaseTip();
}

function captureGrid(rawRect) {
  const rect = normalizeGridRect(rawRect);
  state.hadTwoHandPinch = false;

  if (!rect) {
    state.draftRect = null;
    showError("그리드 영역이 너무 작습니다. 양손 포인트를 더 멀리 벌려 다시 만들어주세요.");
    return;
  }

  hideError();
  const snapshot = document.createElement("canvas");
  snapshot.width = CANVAS_WIDTH;
  snapshot.height = CANVAS_HEIGHT;
  const snapshotCtx = snapshot.getContext("2d");
  drawVideo(snapshotCtx, snapshot);

  state.snapshot = snapshot;
  state.gridRect = rect;
  state.board = createShuffledBoard();
  state.drag = null;
  state.moves = 0;
  state.mode = "puzzle";
  startTimer();
  updateTopbar();
  updatePhaseTip();
}

function processPuzzlePinch(activePinches) {
  if (state.drag) {
    const activeHand = activePinches.find((hand) => hand.id === state.drag.handId);
    if (activeHand) {
      state.drag.point = activeHand.point;
      state.drag.targetIndex = getCellIndex(activeHand.point);
      return;
    }

    completeDrag();
    return;
  }

  const starter = activePinches.find((hand) => getCellIndex(hand.point) >= 0);
  if (!starter) {
    return;
  }

  const fromIndex = getCellIndex(starter.point);
  state.drag = {
    handId: starter.id,
    fromIndex,
    targetIndex: fromIndex,
    point: starter.point,
    piece: state.board[fromIndex]
  };
}

function completeDrag() {
  if (!state.drag) {
    return;
  }

  const { fromIndex, targetIndex } = state.drag;
  if (targetIndex >= 0 && targetIndex !== fromIndex) {
    const temp = state.board[fromIndex];
    state.board[fromIndex] = state.board[targetIndex];
    state.board[targetIndex] = temp;
    state.moves += 1;
    updateTopbar();

    if (isSolved()) {
      finishGame();
    }
  }

  state.drag = null;
}

function finishGame() {
  if (state.mode !== "puzzle") {
    return;
  }

  stopTimer();
  state.mode = "finished";
  const entry = {
    userId: state.userId,
    elapsedMs: state.elapsedMs,
    moves: state.moves,
    createdAt: new Date().toISOString()
  };
  state.rankings.push(entry);
  state.rankings.sort(compareRankingEntries);
  state.rankings = state.rankings.slice(0, 20);
  saveRankings(state.rankings);
  renderLeaderboard();

  finalUser.textContent = state.userId;
  finalTime.textContent = formatTime(state.elapsedMs);
  finalMoves.textContent = String(state.moves);
  finishPanel.classList.remove("hidden");
  updateTopbar();
  updatePhaseTip();
}

function retryGame() {
  hideError();
  finishPanel.classList.add("hidden");
  instructionPanel.classList.remove("hidden");
  resetRoundState();
  setMode("instructions");

  if (!state.stream) {
    startCamera()
      .then(initHands)
      .then(startDetectionLoop)
      .catch((error) => {
        showCameraError(error);
        startPanel.classList.remove("hidden");
        setMode("start");
      });
  }
}

function restartGame() {
  hideError();
  stopTimer();
  stopCamera();
  resetRoundState();
  state.userId = "";
  userIdInput.value = "";
  state.cameraAuthorized = false;
  cameraPermissionInput.checked = false;
  cameraPermissionInput.disabled = false;
  rankPanel.classList.remove("hidden");
  renderLeaderboard();
  syncStartButton();
  instructionPanel.classList.add("hidden");
  finishPanel.classList.add("hidden");
  startPanel.classList.remove("hidden");
  setMode("start");
}

function resetRoundState() {
  stopTimer();
  state.snapshot = null;
  state.gridRect = null;
  state.board = createSolvedBoard();
  state.drag = null;
  state.pointerFrameStart = null;
  state.draftRect = null;
  state.hadTwoHandPinch = false;
  state.elapsedMs = 0;
  state.moves = 0;
  updateTopbar();
}

function handleCanvasPointerDown(event) {
  const point = toCanvasPoint(event);

  if (state.mode === "framing") {
    state.pointerFrameStart = point;
    state.draftRect = rectFromPoints(point, point);
    state.hadTwoHandPinch = true;
    canvas.setPointerCapture?.(event.pointerId);
    return;
  }

  if (state.mode !== "puzzle") {
    return;
  }

  const fromIndex = getCellIndex(point);
  if (fromIndex < 0) {
    return;
  }

  state.drag = {
    handId: "POINTER",
    fromIndex,
    targetIndex: fromIndex,
    point,
    piece: state.board[fromIndex]
  };
  canvas.setPointerCapture?.(event.pointerId);
}

function handleCanvasPointerMove(event) {
  const point = toCanvasPoint(event);

  if (state.mode === "framing" && state.pointerFrameStart) {
    state.draftRect = rectFromPoints(state.pointerFrameStart, point);
    return;
  }

  if (state.mode === "puzzle" && state.drag?.handId === "POINTER") {
    state.drag.point = point;
    state.drag.targetIndex = getCellIndex(point);
  }
}

function handleCanvasPointerUp(event) {
  if (state.mode === "framing" && state.pointerFrameStart) {
    canvas.releasePointerCapture?.(event.pointerId);
    captureGrid(state.draftRect);
    state.pointerFrameStart = null;
    return;
  }

  if (state.mode === "puzzle" && state.drag?.handId === "POINTER") {
    canvas.releasePointerCapture?.(event.pointerId);
    completeDrag();
  }
}

function setMode(mode) {
  state.mode = mode;
  updateTopbar();
  updatePhaseTip();
}

function updateTopbar() {
  const showGameStatus = ["puzzle", "finished"].includes(state.mode);
  statusStrip.classList.toggle("hidden", !showGameStatus);
  topbar.classList.toggle("topbar--setup", !showGameStatus);
  playerBadge.textContent = `USER: ${state.userId || "-"}`;
  phaseLabel.textContent = phaseCopy[state.mode]?.[0] || "READY";
  moveText.textContent = `MOVES: ${state.moves}`;
  timerText.textContent = formatTime(state.elapsedMs);
  timerText.setAttribute("datetime", toDuration(state.elapsedMs));
}

function updatePhaseTip() {
  const [title, body] = phaseCopy[state.mode] || phaseCopy.start;
  const panelMode = ["start", "loading", "instructions", "finished"].includes(state.mode);
  phaseTip.classList.toggle("hidden", panelMode);
  phaseTip.innerHTML = "";
  const strong = document.createElement("strong");
  strong.textContent = title;
  const span = document.createElement("span");
  span.textContent = body;
  phaseTip.append(strong, span);
}

function startTimer() {
  stopTimer();
  state.startTime = performance.now();
  state.elapsedMs = 0;
  state.timerId = window.setInterval(() => {
    state.elapsedMs = performance.now() - state.startTime;
    updateTopbar();
  }, 200);
}

function stopTimer() {
  if (state.timerId) {
    window.clearInterval(state.timerId);
    state.timerId = null;
  }

  if (state.startTime) {
    state.elapsedMs = Math.max(0, performance.now() - state.startTime);
    state.startTime = null;
  }
  updateTopbar();
}

function renderScene() {
  ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  if (video.readyState >= 2 && state.stream && state.mode !== "start") {
    drawVideo(ctx, canvas);
  } else {
    drawWaitingSurface();
  }

  if (state.mode === "framing") {
    drawFramingOverlay();
  }

  if ((state.mode === "puzzle" || state.mode === "finished") && state.snapshot && state.gridRect) {
    drawPuzzle();
  }

  drawHands();
  requestAnimationFrame(renderScene);
}

function drawWaitingSurface() {
  ctx.fillStyle = "#0d0d10";
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;

  for (let x = 0; x < CANVAS_WIDTH; x += 80) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, CANVAS_HEIGHT);
    ctx.stroke();
  }

  for (let y = 0; y < CANVAS_HEIGHT; y += 80) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(CANVAS_WIDTH, y);
    ctx.stroke();
  }

  ctx.fillStyle = "rgba(243,246,237,0.62)";
  ctx.font = "800 24px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("CAMERA WAITING", CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
}

function drawVideo(targetCtx, targetCanvas) {
  const rect = getVideoCoverRect(targetCanvas);
  targetCtx.save();
  targetCtx.translate(targetCanvas.width, 0);
  targetCtx.scale(-1, 1);
  targetCtx.drawImage(video, rect.x, rect.y, rect.width, rect.height);
  targetCtx.restore();
}

function drawFramingOverlay() {
  if (!state.draftRect) {
    return;
  }

  const rect = normalizeRect(state.draftRect);
  ctx.save();
  ctx.fillStyle = "rgba(199,255,69,0.10)";
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  drawGridLines(rect, "rgba(199,255,69,0.92)", 4);
  drawCorner(rect.x, rect.y, "#c7ff45");
  drawCorner(rect.x + rect.width, rect.y, "#66e4ff");
  drawCorner(rect.x, rect.y + rect.height, "#66e4ff");
  drawCorner(rect.x + rect.width, rect.y + rect.height, "#c7ff45");
  ctx.restore();
}

function drawPuzzle() {
  const rect = state.gridRect;
  const cellW = rect.width / 3;
  const cellH = rect.height / 3;
  const draggedFrom = state.drag?.fromIndex ?? -1;

  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.42)";
  ctx.fillRect(rect.x - 8, rect.y - 8, rect.width + 16, rect.height + 16);

  for (let pos = 0; pos < 9; pos += 1) {
    if (pos === draggedFrom) {
      drawCellPlaceholder(pos, rect, cellW, cellH);
      continue;
    }

    drawTile(pos, state.board[pos], rect, cellW, cellH, 1);
  }

  if (state.drag) {
    const targetIndex = state.drag.targetIndex;
    if (targetIndex >= 0) {
      drawTargetCell(targetIndex, rect, cellW, cellH);
    }
    drawFloatingTile(state.drag.piece, state.drag.point, rect, cellW, cellH);
  }

  drawGridLines(rect, "rgba(255,255,255,0.88)", 3);
  ctx.restore();
}

function drawTile(position, piece, rect, cellW, cellH, alpha) {
  const destCol = position % 3;
  const destRow = Math.floor(position / 3);
  const srcCol = piece % 3;
  const srcRow = Math.floor(piece / 3);

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.drawImage(
    state.snapshot,
    rect.x + srcCol * cellW,
    rect.y + srcRow * cellH,
    cellW,
    cellH,
    rect.x + destCol * cellW,
    rect.y + destRow * cellH,
    cellW,
    cellH
  );
  ctx.restore();
}

function drawFloatingTile(piece, point, rect, cellW, cellH) {
  const srcCol = piece % 3;
  const srcRow = Math.floor(piece / 3);
  const dx = clamp(point.x - cellW / 2, 0, CANVAS_WIDTH - cellW);
  const dy = clamp(point.y - cellH / 2, 0, CANVAS_HEIGHT - cellH);

  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.55)";
  ctx.shadowBlur = 24;
  ctx.globalAlpha = 0.94;
  ctx.drawImage(
    state.snapshot,
    rect.x + srcCol * cellW,
    rect.y + srcRow * cellH,
    cellW,
    cellH,
    dx,
    dy,
    cellW,
    cellH
  );
  ctx.strokeStyle = "#c7ff45";
  ctx.lineWidth = 5;
  ctx.strokeRect(dx, dy, cellW, cellH);
  ctx.restore();
}

function drawCellPlaceholder(position, rect, cellW, cellH) {
  const col = position % 3;
  const row = Math.floor(position / 3);
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.46)";
  ctx.fillRect(rect.x + col * cellW, rect.y + row * cellH, cellW, cellH);
  ctx.restore();
}

function drawTargetCell(position, rect, cellW, cellH) {
  const col = position % 3;
  const row = Math.floor(position / 3);
  ctx.save();
  ctx.strokeStyle = "#ffbd59";
  ctx.lineWidth = 6;
  ctx.strokeRect(rect.x + col * cellW + 3, rect.y + row * cellH + 3, cellW - 6, cellH - 6);
  ctx.restore();
}

function drawGridLines(rect, color, width) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.strokeRect(rect.x, rect.y, rect.width, rect.height);

  for (let i = 1; i < 3; i += 1) {
    const x = rect.x + (rect.width / 3) * i;
    const y = rect.y + (rect.height / 3) * i;
    ctx.beginPath();
    ctx.moveTo(x, rect.y);
    ctx.lineTo(x, rect.y + rect.height);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(rect.x, y);
    ctx.lineTo(rect.x + rect.width, y);
    ctx.stroke();
  }
  ctx.restore();
}

function drawCorner(x, y, color) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = "rgba(0,0,0,0.64)";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(x, y, 13, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function drawHands() {
  if (!state.latestHands.length) {
    return;
  }

  ctx.save();
  state.latestHands.forEach((hand) => {
    const color = hand.isPinching ? "#c7ff45" : "#66e4ff";
    ctx.strokeStyle = "rgba(255,255,255,0.34)";
    ctx.lineWidth = 3;
    drawSegment(hand.thumb, hand.indexTip);

    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(hand.point.x, hand.point.y, hand.isPinching ? 13 : 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(0,0,0,0.66)";
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = "#050506";
    ctx.font = "900 12px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    if (hand.isPinching) {
      ctx.fillText("P", hand.point.x, hand.point.y + 0.5);
    }
  });
  ctx.restore();
}

function drawSegment(a, b) {
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
}

function mapLandmark(landmark) {
  const rect = getVideoCoverRect(canvas);
  const videoWidth = video.videoWidth || CANVAS_WIDTH;
  const videoHeight = video.videoHeight || CANVAS_HEIGHT;
  return {
    x: rect.x + (1 - landmark.x) * videoWidth * rect.scale,
    y: rect.y + landmark.y * videoHeight * rect.scale
  };
}

function getVideoCoverRect(targetCanvas) {
  const videoWidth = video.videoWidth || CANVAS_WIDTH;
  const videoHeight = video.videoHeight || CANVAS_HEIGHT;
  const scale = Math.max(targetCanvas.width / videoWidth, targetCanvas.height / videoHeight);
  const width = videoWidth * scale;
  const height = videoHeight * scale;
  return {
    x: (targetCanvas.width - width) / 2,
    y: (targetCanvas.height - height) / 2,
    width,
    height,
    scale
  };
}

function rectFromPoints(a, b) {
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    width: Math.abs(a.x - b.x),
    height: Math.abs(a.y - b.y)
  };
}

function normalizeRect(rect) {
  const x1 = clamp(Math.min(rect.x, rect.x + rect.width), 0, CANVAS_WIDTH);
  const y1 = clamp(Math.min(rect.y, rect.y + rect.height), 0, CANVAS_HEIGHT);
  const x2 = clamp(Math.max(rect.x, rect.x + rect.width), 0, CANVAS_WIDTH);
  const y2 = clamp(Math.max(rect.y, rect.y + rect.height), 0, CANVAS_HEIGHT);
  return {
    x: x1,
    y: y1,
    width: x2 - x1,
    height: y2 - y1
  };
}

function normalizeGridRect(rect) {
  const normalized = normalizeRect(rect);
  if (normalized.width < 220 || normalized.height < 180) {
    return null;
  }
  return normalized;
}

function getCellIndex(point) {
  const rect = state.gridRect;
  if (!rect) {
    return -1;
  }

  if (point.x < rect.x || point.x > rect.x + rect.width || point.y < rect.y || point.y > rect.y + rect.height) {
    return -1;
  }

  const col = clamp(Math.floor(((point.x - rect.x) / rect.width) * 3), 0, 2);
  const row = clamp(Math.floor(((point.y - rect.y) / rect.height) * 3), 0, 2);
  return row * 3 + col;
}

function createSolvedBoard() {
  return Array.from({ length: 9 }, (_, index) => index);
}

function createShuffledBoard() {
  const board = createSolvedBoard();
  do {
    for (let i = board.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [board[i], board[j]] = [board[j], board[i]];
    }
  } while (board.every((piece, index) => piece === index));
  return board;
}

function isSolved() {
  return state.board.every((piece, index) => piece === index);
}

function pointInsideElement(point, element) {
  const canvasRect = canvas.getBoundingClientRect();
  const elementRect = element.getBoundingClientRect();
  const screenX = canvasRect.left + (point.x / CANVAS_WIDTH) * canvasRect.width;
  const screenY = canvasRect.top + (point.y / CANVAS_HEIGHT) * canvasRect.height;
  return screenX >= elementRect.left && screenX <= elementRect.right && screenY >= elementRect.top && screenY <= elementRect.bottom;
}

function toCanvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((event.clientX - rect.left) / rect.width) * CANVAS_WIDTH,
    y: ((event.clientY - rect.top) / rect.height) * CANVAS_HEIGHT
  };
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function formatTime(milliseconds) {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function toDuration(milliseconds) {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `PT${minutes}M${seconds}S`;
}

function compareRankingEntries(a, b) {
  const aElapsed = Number(a.elapsedMs) || 0;
  const bElapsed = Number(b.elapsedMs) || 0;
  const aSeconds = Math.floor(aElapsed / 1000);
  const bSeconds = Math.floor(bElapsed / 1000);
  return aSeconds - bSeconds || (Number(a.moves) || 0) - (Number(b.moves) || 0) || aElapsed - bElapsed || String(a.createdAt || "").localeCompare(String(b.createdAt || ""));
}

function loadRankings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.sort(compareRankingEntries) : [];
  } catch {
    return [];
  }
}

function saveRankings(rankings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rankings));
  } catch {
    showError("랭킹을 브라우저 저장소에 기록하지 못했습니다.");
  }
}

function resetRankings() {
  if (!state.rankings.length) {
    renderLeaderboard();
    return;
  }

  const confirmed = window.confirm("Score Ranking 기록을 초기화할까요?");
  if (!confirmed) {
    return;
  }

  state.rankings = [];
  localStorage.removeItem(STORAGE_KEY);
  renderLeaderboard();
}

function renderLeaderboard() {
  rankList.innerHTML = "";
  state.rankings.sort(compareRankingEntries);

  if (!state.rankings.length) {
    const empty = document.createElement("li");
    empty.className = "rank-empty";
    empty.textContent = "아직 저장된 기록이 없습니다.";
    rankList.append(empty);
    return;
  }

  state.rankings.slice(0, 10).forEach((entry, index) => {
    const item = document.createElement("li");
    const rank = document.createElement("span");
    const user = document.createElement("span");
    const time = document.createElement("span");

    rank.className = "rank-num";
    user.className = "rank-user";
    time.className = "rank-time";
    rank.textContent = `#${index + 1}`;
    user.textContent = `${entry.userId} · ${entry.moves} moves`;
    time.textContent = formatTime(entry.elapsedMs);

    item.append(rank, user, time);
    rankList.append(item);
  });
}

function showCameraError(error) {
  const name = error?.name || error?.message || "Error";
  showError(`카메라 권한 또는 장치 연결을 확인하세요. (${name})`);
}

function showError(message) {
  errorBanner.textContent = message;
  errorBanner.classList.remove("hidden");
  window.clearTimeout(showError.timeoutId);
  showError.timeoutId = window.setTimeout(() => {
    errorBanner.classList.add("hidden");
  }, 5600);
}

function hideError() {
  window.clearTimeout(showError.timeoutId);
  errorBanner.classList.add("hidden");
}

function stopCamera() {
  state.detectionActive = false;
  if (state.stream) {
    state.stream.getTracks().forEach((track) => track.stop());
  }
  state.stream = null;
  state.cameraAuthorized = false;
  video.srcObject = null;
  state.latestHands = [];
}
