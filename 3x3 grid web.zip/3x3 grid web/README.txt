3x3 Grid Puzzle - Web

필요 파일:
- index.html
- app.js
- styles.css

권장 실행 방법:
1. run-web.cmd를 실행합니다.
2. 브라우저에서 http://127.0.0.1:5173/ 로 접속합니다.
3. 카메라 권한 요청이 나오면 허용합니다.

간단 실행:
- index.html을 더블클릭해서 열 수도 있습니다.
- 다만 카메라 권한은 브라우저 정책상 로컬 서버 실행 방식이 더 안정적입니다.

권장 브라우저:
- Chrome 또는 Microsoft Edge
